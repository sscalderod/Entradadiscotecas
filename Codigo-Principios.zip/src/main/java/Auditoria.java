
public class Auditoria
{
	private String fecha;
	private String respuesta;
	
	public Auditoria(){
		super();
	}
	public void registrarAuditoria(String fecha, String respuesta) {
	}
}