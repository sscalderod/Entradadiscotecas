public class Comparendo
{
	private String fecha;
	private String respuesta;
	
	public Comparendo(){
		super();
	}
	public void registrarComparendo(String fecha, String respuesta) {
		
	}
	public void solicitarComparendo() {
		
	}

	public void guardarComparendo(String fecha, String respuesta) {
			
	}
	
}