public class Notificacion
{
	private int numeroContactoAutoridad;
	private int numeroContactoAdultoResponsable;
	
	public Notificacion(){
		super();
	}

	public void notificarAutoridad(int numeroContactoAutoridad) {
		
	}
	
	public void notificarAdultoResponsable(int numeroContactoAdultoResponsable) {
		
	}
	
}