import java.io.FileWriter;
import java.io.IOException;

public class Auditoria
{
	private String fecha;
	private String respuesta;
	
	public Auditoria(){
		super();
	}
  public static void registrarAuditoria(String fileName) {
    String message = "Se registro la auditoria correctamente";
    try (FileWriter writer = new FileWriter(fileName, true)) {
        writer.write(message + "\n");
    } catch (IOException e) {
        e.printStackTrace();
    }
  }
}