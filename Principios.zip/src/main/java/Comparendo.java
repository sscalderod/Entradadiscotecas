import java.io.FileWriter;
import java.io.IOException;

public class Comparendo
{
	private String fecha;
	private String respuesta;
	
	public Comparendo(){
		super();
	}
  public static void registrarComparendo(String fileName) {
    String message = "No se ha infringido la ley, no se registro el comparendo";
    try (FileWriter writer = new FileWriter(fileName, true)) {
        writer.write(message + "\n");
    } catch (IOException e) {
        e.printStackTrace();
    }
  }
}