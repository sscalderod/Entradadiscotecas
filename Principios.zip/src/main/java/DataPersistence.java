
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.ArrayList;

public class DataPersistence {
    private static final String FILE_NAME = "userData.txt";

    public static void saveUserData(String fileName, List<Usuario> users) {
        File file = new File(fileName);
        try (FileWriter writer = new FileWriter(file, true)) {
            for (Usuario user : users) {
                writer.write(user.getNombre() + "," + user.getDocumento() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

  public static List<Usuario> loadUserData(String fileName) {
      List<Usuario> users = new ArrayList<>();
      try {
          List<String> lines = Files.readAllLines(Paths.get(fileName));
          for (String line : lines) {
              String[] parts = line.split(",");
              if (parts.length == 2) {
                  String nombre = parts[0].trim();
                  int documento = Integer.parseInt(parts[1].trim());
                  Usuario user = new Usuario(nombre, 0, documento);
                  boolean userExists = false;
                  for (Usuario existingUser : users) {
                      if (existingUser.getNombre().equals(user.getNombre()) && existingUser.getDocumento() == user.getDocumento()) {
                          userExists = true;
                          break;
                      }
                  }

                  if (!userExists) {
                      users.add(user);
                  }
              }
          }
      } catch (IOException e) {
          e.printStackTrace();
      }
      return users;
  }
}
