public class Notificacion
{
	private int numeroContactoAutoridad;
	private int numeroContactoAdultoResponsable;
	
	public Notificacion(){
		super();
	}

	public void notificarAutoridad(String texto) {
		Main.informa.setText(texto);
	}

	public void notificarAdultoResponsable(String texto) {
		Main.notificando.setText(texto);
	}
	
}